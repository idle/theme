---
Title: Contact
type: list
---


#### LinkedIn
If you have a short message or question, drop a message via [LinkedIn](https://www.linkedin.com/in/heycharlola/).


<!-- #### Email
For enquiries or longer messages, please email me. -->



