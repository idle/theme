---
title: Math Braintrainer
dateMonthYear: April 2022
description:  It's a game to train your mental calculation skills. During a fixed time period, randomized math questions pop up. How many of them can you answer correctly?
type: page
topic: project
link: "https://www.mathbraintrainer.com"
image: "/images/braintrainer.png"
---


